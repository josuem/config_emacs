import random

def f(x):
    return random.randrange(1, x)


for i in range(2,10):
    print f(i)
    
            

if __name__ == '__main__':
    hello


class myclass(somethingelse):
    """documentation

    """
    def __init__(self, some_args):
        super(myclass, self).__init__()
        self.some_args = some_args
        
        
